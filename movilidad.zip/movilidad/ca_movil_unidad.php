<?PHP header('Expires: 0');
  require('../../includes/Seguridad.php');
  require('../../includes/Connection.php');
  require('../../includes/Constantes.php');
  require('../includes/clsca_movilidad_unidad.php');

 $movil_unidad_codigo='';
 $movil_unidad_descripcion='';
 $movil_unidad_capacidad='';
 $movil_unidad_placa='';
 $movil_unidad_chofer='';
 $movil_unidad_activo='';
 $fecha_registro='';
 $usuario_registro='';
 $fecha_modifica='';
 $usuario_modifica='';

   $o = new ca_movilidad_unidad();
   $o->MyDBName= db_name();
   $o->MyUrl = db_host();
   $o->MyUser= db_user();
   $o->MyPwd = db_pass();

   $sRpta="";
   $pagina= "";
   $orden= "";
   $buscam= "";

   if (isset($HTTP_GET_VARS["pagina"])){
       $pagina= $HTTP_GET_VARS["pagina"];
       $orden= $HTTP_GET_VARS["orden"];
       $buscam= $HTTP_GET_VARS["buscam"];
   }else{
       $pagina= $HTTP_POST_VARS["pagina"];
       $orden= $HTTP_POST_VARS["orden"];
       $buscam= $HTTP_POST_VARS["buscam"];
   }

  if (isset($HTTP_POST_VARS["movil_unidad_codigo"])){
   $movil_unidad_codigo = $HTTP_POST_VARS["movil_unidad_codigo"];
  }else{
   $movil_unidad_codigo = $HTTP_GET_VARS["movil_unidad_codigo"];
  }
  if (isset($HTTP_POST_VARS["movil_unidad_descripcion"])){
   $movil_unidad_descripcion = $HTTP_POST_VARS["movil_unidad_descripcion"];
  }
  if (isset($HTTP_POST_VARS["movil_unidad_capacidad"])){
   $movil_unidad_capacidad = $HTTP_POST_VARS["movil_unidad_capacidad"];
  }
  if (isset($HTTP_POST_VARS["movil_unidad_placa"])){
   $movil_unidad_placa = $HTTP_POST_VARS["movil_unidad_placa"];
  }
  if (isset($HTTP_POST_VARS["movil_unidad_chofer"])){
   $movil_unidad_chofer = $HTTP_POST_VARS["movil_unidad_chofer"];
  }
  if (isset($HTTP_POST_VARS["movil_unidad_activo"])){
   $movil_unidad_activo = $HTTP_POST_VARS["movil_unidad_activo"];
  }

  if (isset($HTTP_POST_VARS["hddaccion"])){
     if ($HTTP_POST_VARS["hddaccion"]=="SVE"){//la orden es grabar
       $o->movil_unidad_descripcion= $HTTP_POST_VARS["movil_unidad_descripcion"];
       $o->movil_unidad_capacidad= $HTTP_POST_VARS["movil_unidad_capacidad"];
       $o->movil_unidad_placa= $HTTP_POST_VARS["movil_unidad_placa"];
       $o->movil_unidad_chofer= $HTTP_POST_VARS["movil_unidad_chofer"];
       $o->movil_unidad_activo= $HTTP_POST_VARS["movil_unidad_activo"];

       if ($HTTP_POST_VARS["movil_unidad_codigo"]==""){
           //Insertar
           $sRpta = $o->AddNew();
           $movil_unidad_codigo = $o->movil_unidad_codigo;
       }else{
           //Actualizar
          $o->movil_unidad_codigo=$movil_unidad_codigo;
          $sRpta = $o->Update();
       }
       if ($sRpta!="OK"){
           echo $sRpta;
       }else{
       	?>
       	<script language=javascript>
       	alert('Se guardo registro');
       	</script>
       	<?php
       }
     }
  }else{
     if (isset($HTTP_GET_VARS["codigo"])) $movil_unidad_codigo= $HTTP_GET_VARS["codigo"];
     if ($movil_unidad_codigo!=""){
        $o->movil_unidad_codigo=$movil_unidad_codigo;
        //Recuperar datos del Registro
        $sRpta = $o->Query();
        if ($sRpta!="OK"){
            echo sRpta;
        }
           $movil_unidad_descripcion = $o->movil_unidad_descripcion;
           $movil_unidad_capacidad = $o->movil_unidad_capacidad;
           $movil_unidad_placa = $o->movil_unidad_placa;
           $movil_unidad_chofer = $o->movil_unidad_chofer;
           $movil_unidad_activo = $o->movil_unidad_activo;
           $fecha_registro = $o->fecha_registro;
           $usuario_registro = $o->usuario_registro;
           $fecha_modifica = $o->fecha_modifica;
           $usuario_modifica = $o->usuario_modifica;

     }
  }
?>
<HTML>
<HEAD>
<meta http-equiv='pragma' content='no-cache'>
<META NAME=author CONTENT='TUMI Solutions S.A.C.'>
<title>Maestro de Unidades de Transporte</title>
<link rel="stylesheet" type="text/css" href="../../default.css">
<script language="JavaScript" src="../../default.js"></script>
</HEAD>
<body Class='PageBody'  >
<center class=TITOpciones>Maestro de Unidades de Transporte</center>

<script language='javascript'>
function confirmar(){
	if (validarEntrada('movil_unidad_descripcion')==false) return false;
    if (validarEntrada('movil_unidad_capacidad')==false) return false;
 if (confirm('confirme guardar los datos')== false){
     return false;
 }
 document.frm.hddaccion.value='SVE';
 return true;
}
</script>
<form name='frm' id='frm' action='<?php echo $PHP_SELF; ?>' method='post'  onSubmit='javascript:return confirmar();'>
<table  class='Table' width='70%' align='center' cellspacing='1' cellpadding='1' border='0'>
<tr>
 <td  class='ColumnTD'  align='right'>
     C�digo &nbsp;</td>
 <td  class='DataTD'>
     <Input  class='Input' type='text' name='movil_unidad_codigo' id='movil_unidad_codigo' value='<?php echo $movil_unidad_codigo?>' size='7' readOnly >
 </td>
</tr>
<tr>
 <td  class='ColumnTD'  align='right'>
     Descripci�n &nbsp;</td>
 <td  class='DataTD'>
     <Input  class='Input' type='text' name='movil_unidad_descripcion' id='movil_unidad_descripcion' value='<?php echo $movil_unidad_descripcion?>' size='51' maxlength='80' alt='Descripci�n'> (*)
 </td>
</tr>
<tr>
 <td  class='ColumnTD'  align='right'>
     Capacidad &nbsp;</td>
 <td  class='DataTD'>
     <Input  class='Input' type='text' name='movil_unidad_capacidad' id='movil_unidad_capacidad' value='<?php echo $movil_unidad_capacidad?>' size='7' alt='Capacidad' > (*)
 </td>
</tr>
<tr>
 <td  class='ColumnTD'  align='right'>
     Nro. Placa &nbsp;</td>
 <td  class='DataTD'>
     <Input  class='Input' type='text' name='movil_unidad_placa' id='movil_unidad_placa' value='<?php echo $movil_unidad_placa?>' size='11' maxlength='10' alt='Nro. de Placa'>
 </td>
</tr>
<tr>
 <td  class='ColumnTD'  align='right'>
     Nombre Conductor &nbsp;</td>
 <td  class='DataTD'>
     <Input  class='Input' type='text' name='movil_unidad_chofer' id='movil_unidad_chofer' value='<?php echo $movil_unidad_chofer?>' size='51' maxlength='80' alt='Nombre de Conductor'>
 </td>
</tr>
<tr>
 <td  class='ColumnTD'  align='right'>
     Activo &nbsp;</td>
 <td  class='DataTD'>
     <Input  class='Input' type='checkbox' name='movil_unidad_activo' id='movil_unidad_activo' value='1' <?php if ($movil_unidad_activo*1==1) echo 'Checked' ?>>
 </td>
</tr>
<tr>
 <td colspan=2  class='ColumnTD'>&nbsp;
 </td>
</tr>
<tr align='center'>
 <td colspan=2  class='ColumnTD'>
   <input name='cmdGuardar' id='cmdGuardar' type='submit' value='Guardar'  class='Button' style='width:70px' >
   <input name='cmdCerrar' id='cmdCerrar' type='button' value='Cerrar'  class='Button' style='width:70px' onclick="self.location.href='../../mantenimientos/main_ca_movil_unidad.php?pagina=<?php echo $pagina?>&orden=<?php echo $orden?>&buscam=<?php echo $buscam?>'" >
 </td>
</tr>
<input type='hidden' name='pagina' id='pagina' value='<?php echo $pagina ?>'>
<input type='hidden' name='orden' id='orden' value='<?php echo $orden ?>'>
<input type='hidden' name='buscam' id='buscam' value='<?php echo $buscam ?>'>
<input type='hidden' name='hddaccion' id='hddaccion' value=''>
</table>
</form>
</body>
</HTML>
<!-- TUMI Solutions S.A.C.-->
